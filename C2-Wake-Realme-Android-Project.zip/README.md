# C2 Wake — Custom Volume Screen Controller for Realme C2

Tailored specifically for the **Realme C2 (RMX1941 / RMX1945, ColorOS 6 / Android 9 Pie)** when the physical power button is damaged or unresponsive.

## Your Configured Gestures

- **Screen Wake (Screen OFF):** Single Click on Volume Up
- **Screen Lock (Screen ON):** Long Press (Volume Down)
- **Double-Click Detection Window:** 360 ms
- **Pocket Protection (Proximity Sensor):** Enabled
- **Media / Call Safeguard:** Enabled
- **Screen-Off Engine:** MediaSession Volume Intercept (Low Battery)

## How to Build the Installable APK (2 Options)

### Option A: Build Free in the Cloud via GitHub (No Android Studio Required)
1. Create a new repository on GitHub and upload all files from this ZIP.
2. Open the **Actions** tab in your GitHub repository.
3. Click **Build Realme C2 APK** -> **Run workflow**.
4. Once complete (~2 minutes), download **C2Wake-RealmeC2-APK**, unzip it, transfer `app-debug.apk` to your Realme C2, and tap to install.

### Option B: Build Locally with Android Studio
1. Open this extracted folder in Android Studio.
2. Wait for Gradle sync to finish.
3. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your Realme C2 and install.

## Required Realme C2 (ColorOS 6) Settings After Install

ColorOS 6 aggressively stops background apps unless you enable these four settings:

1. Open **C2 Wake** and tap **Start Screen-Off Volume Service**.
2. Tap **Enable Accessibility Service** -> turn ON **C2 Wake Volume Controller**.
3. Open Recent Apps, pull down on **C2 Wake** (or tap the menu icon), and tap **Lock** so ColorOS never clears it.
4. Go to **Settings -> App Management -> C2 Wake -> Power Saver** -> enable **Allow Background Running** and **Allow Auto-Startup**.
