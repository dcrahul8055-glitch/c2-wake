package com.c2wake.realme

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 72, 56, 56)
        }

        val title = TextView(this).apply {
            text = "C2 Wake — Realme C2"
            textSize = 22f
            setPadding(0, 0, 0, 16)
        }

        val summary = TextView(this).apply {
            text = """
                Screen Wake: Single Click on Volume Up
                Screen Lock: Long Press (Volume Down)
                Double-Click Window: 360 ms
                Pocket Protection: Enabled
            """.trimIndent()
            textSize = 14f
            setPadding(0, 0, 0, 36)
        }

        val startServiceBtn = Button(this).apply {
            text = "1. Start Screen-Off Volume Service"
            setOnClickListener {
                val intent = Intent(this@MainActivity, ScreenWakeForegroundService::class.java)
                ContextCompat.startForegroundService(this@MainActivity, intent)
            }
        }

        val accessibilityBtn = Button(this).apply {
            text = "2. Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val batteryBtn = Button(this).apply {
            text = "3. Allow Background Running (Battery)"
            setOnClickListener {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } else {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }

        val testLockBtn = Button(this).apply {
            text = "Test Lock Screen Now"
            setOnClickListener {
                sendBroadcast(Intent(WakeConfig.ACTION_LOCK_SCREEN_NOW).setPackage(packageName))
            }
        }

        container.addView(title)
        container.addView(summary)
        container.addView(startServiceBtn)
        container.addView(accessibilityBtn)
        container.addView(batteryBtn)
        container.addView(testLockBtn)

        setContentView(container)
    }
}
