package com.c2wake.realme

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media.VolumeProviderCompat

/**
 * Keeps hardware volume button detection reliable while the Realme screen is turned off.
 * Compatible with Realme C2 (Android 9) and Realme 12x 5G RMX3998 (Android 14).
 * Engine mode: MEDIA_SESSION
 */
class ScreenWakeForegroundService : Service(), SensorEventListener {

    private lateinit var powerManager: PowerManager
    private var mediaSession: MediaSessionCompat? = null
    private var partialWakeLock: PowerManager.WakeLock? = null
    private var sensorManager: SensorManager? = null
    private var isNearPocket = false

    private var lastDirection = 0
    private var lastPressMs = 0L

    override fun onCreate() {
        super.onCreate()
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        createNotificationChannel()
        val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), fgType)

        if (WakeConfig.POCKET_PROTECTION) {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }

        if (WakeConfig.WAKE_ENGINE == "MEDIA_SESSION") {
            initMediaSessionVolumeIntercept()
        } else {
            initPartialWakeLock()
        }
    }

    private fun initMediaSessionVolumeIntercept() {
        val session = MediaSessionCompat(this, "C2WakeVolumeSession")
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setState(PlaybackStateCompat.STATE_PLAYING, 0L, 0f)
                .build()
        )

        val volumeProvider = object : VolumeProviderCompat(VOLUME_CONTROL_RELATIVE, 100, 50) {
            override fun onAdjustVolume(direction: Int) {
                if (direction == 0 || powerManager.isInteractive) return
                handleScreenOffVolumeStep(direction)
            }
        }

        session.setPlaybackToRemote(volumeProvider)
        session.isActive = true
        mediaSession = session
    }

    private fun initPartialWakeLock() {
        // Keeps the CPU awake in low-power state so AccessibilityService.onKeyEvent fires while screen is off
        partialWakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "com.c2wake.realme:KeepKeyEventsAlive"
        ).apply {
            acquire()
        }
    }

    private fun handleScreenOffVolumeStep(direction: Int) {
        val isUp = direction > 0
        val matchesTarget = when (WakeConfig.WAKE_KEY) {
            "VOL_UP" -> isUp
            "VOL_DOWN" -> !isUp
            else -> true
        }
        if (!matchesTarget) return

        val now = SystemClock.elapsedRealtime()
        val delta = now - lastPressMs
        val isDouble = (direction == lastDirection) && (delta in 1..WakeConfig.DOUBLE_CLICK_WINDOW_MS)

        if (WakeConfig.WAKE_GESTURE == "SINGLE_CLICK") {
            wakeDisplay()
        } else if (WakeConfig.WAKE_GESTURE == "DOUBLE_CLICK" && isDouble) {
            lastPressMs = 0L
            wakeDisplay()
            return
        }

        lastDirection = direction
        lastPressMs = now
    }

    @Suppress("DEPRECATION")
    private fun wakeDisplay() {
        if (WakeConfig.POCKET_PROTECTION && isNearPocket) return
        val lock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "com.c2wake.realme:ScreenWake"
        )
        lock.acquire(3000L)
        if (lock.isHeld) lock.release()
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("C2 Wake Active on Realme C2")
            .setContentText("Wake: Single Click (Volume Up)")
            .setSmallIcon(android.R.drawable.ic_lock_power_off)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)

        if (WakeConfig.PERSISTENT_NOTIFICATION_LOCK) {
            val lockIntent = PendingIntent.getBroadcast(
                this,
                1,
                Intent(WakeConfig.ACTION_LOCK_SCREEN_NOW).setPackage(packageName),
                PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_lock_lock, "Lock Screen Now", lockIntent)
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "C2 Wake Background Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaSession?.isActive = false
        mediaSession?.release()
        partialWakeLock?.let { if (it.isHeld) it.release() }
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_PROXIMITY) {
            isNearPocket = event.values[0] < event.sensor.maximumRange && event.values[0] < 3.0f
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "c2_wake_service_channel"
        private const val NOTIFICATION_ID = 1941
    }
}
