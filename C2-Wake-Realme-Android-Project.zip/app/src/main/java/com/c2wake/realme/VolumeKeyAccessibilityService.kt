package com.c2wake.realme

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeKeyAccessibilityService : AccessibilityService(), SensorEventListener {

    private lateinit var powerManager: PowerManager
    private lateinit var audioManager: AudioManager
    private var sensorManager: SensorManager? = null
    private var proximitySensor: Sensor? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isNearPocket = false

    private var lastClickKey = -1
    private var lastClickTimeMs = 0L
    private var volUpPressed = false
    private var volDownPressed = false
    private var longPressTriggered = false

    private val longPressRunnable = Runnable {
        longPressTriggered = true
        val screenOn = powerManager.isInteractive
        if (!screenOn && WakeConfig.WAKE_GESTURE == "LONG_PRESS") {
            wakeScreenIfAllowed()
        } else if (screenOn && WakeConfig.LOCK_GESTURE == "LONG_PRESS") {
            lockScreenNow()
        }
    }

    private val lockActionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WakeConfig.ACTION_LOCK_SCREEN_NOW) {
                lockScreenNow()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (WakeConfig.POCKET_PROTECTION) {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            proximitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
            proximitySensor?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }

        val filter = IntentFilter(WakeConfig.ACTION_LOCK_SCREEN_NOW)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(lockActionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(lockActionReceiver, filter)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyEvent(event)
        }

        val screenOn = powerManager.isInteractive

        // Track simultaneous press for Volume Up + Down chord
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (code == KeyEvent.KEYCODE_VOLUME_UP) volUpPressed = true
            if (code == KeyEvent.KEYCODE_VOLUME_DOWN) volDownPressed = true

            if (screenOn && WakeConfig.LOCK_GESTURE == "CHORD" && volUpPressed && volDownPressed) {
                handler.removeCallbacks(longPressRunnable)
                lockScreenNow()
                return true
            }

            // Avoid hijacking normal media/call volume while screen is on
            if (screenOn && WakeConfig.MEDIA_SAFEGUARD && isAudioOrCallActive()) {
                return false
            }

            if (event.repeatCount == 0) {
                longPressTriggered = false
                val shouldWatchLongPress =
                    (!screenOn && WakeConfig.WAKE_GESTURE == "LONG_PRESS" && matchesKey(code, WakeConfig.WAKE_KEY)) ||
                    (screenOn && WakeConfig.LOCK_GESTURE == "LONG_PRESS" && matchesKey(code, WakeConfig.LOCK_KEY))

                if (shouldWatchLongPress) {
                    handler.postDelayed(longPressRunnable, WakeConfig.LONG_PRESS_DURATION_MS)
                }
            }
            return !screenOn // Consume screen-off presses so volume doesn't jump unexpectedly
        }

        if (event.action == KeyEvent.ACTION_UP) {
            if (code == KeyEvent.KEYCODE_VOLUME_UP) volUpPressed = false
            if (code == KeyEvent.KEYCODE_VOLUME_DOWN) volDownPressed = false
            handler.removeCallbacks(longPressRunnable)

            if (longPressTriggered) {
                longPressTriggered = false
                return true
            }

            val now = SystemClock.elapsedRealtime()
            val delta = now - lastClickTimeMs
            val isDoubleClick = (code == lastClickKey) && (delta in 1..WakeConfig.DOUBLE_CLICK_WINDOW_MS)

            if (!screenOn && matchesKey(code, WakeConfig.WAKE_KEY)) {
                if (WakeConfig.WAKE_GESTURE == "SINGLE_CLICK") {
                    wakeScreenIfAllowed()
                    return true
                }
                if (WakeConfig.WAKE_GESTURE == "DOUBLE_CLICK" && isDoubleClick) {
                    lastClickTimeMs = 0L
                    wakeScreenIfAllowed()
                    return true
                }
            }

            if (screenOn && WakeConfig.LOCK_GESTURE == "DOUBLE_CLICK" && matchesKey(code, WakeConfig.LOCK_KEY)) {
                if (WakeConfig.MEDIA_SAFEGUARD && isAudioOrCallActive()) {
                    return false
                }
                if (isDoubleClick) {
                    lastClickTimeMs = 0L
                    lockScreenNow()
                    return true
                }
            }

            lastClickKey = code
            lastClickTimeMs = now
        }

        return super.onKeyEvent(event)
    }

    private fun matchesKey(keyCode: Int, target: String): Boolean {
        return when (target) {
            "VOL_UP" -> keyCode == KeyEvent.KEYCODE_VOLUME_UP
            "VOL_DOWN" -> keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
            else -> keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        }
    }

    private fun isAudioOrCallActive(): Boolean {
        val mode = audioManager.mode
        val inCall = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION || mode == AudioManager.MODE_RINGTONE
        return audioManager.isMusicActive || inCall
    }

    @Suppress("DEPRECATION")
    private fun wakeScreenIfAllowed() {
        if (WakeConfig.POCKET_PROTECTION && isNearPocket) return
        val wakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "com.c2wake.realme:VolumeWake"
        )
        wakeLock.acquire(3000L)
        if (wakeLock.isHeld) wakeLock.release()
        triggerHaptic()
    }

    private fun lockScreenNow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Android 9 Pie (Realme C2 ColorOS 6) supports native lock screen without Device Admin
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            triggerHaptic()
        }
    }

    private fun triggerHaptic() {
        if (!WakeConfig.HAPTIC_FEEDBACK) return
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(28, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(28)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_PROXIMITY) {
            val maxRange = event.sensor.maximumRange
            isNearPocket = event.values[0] < maxRange && event.values[0] < 3.0f
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        sensorManager?.unregisterListener(this)
        try {
            unregisterReceiver(lockActionReceiver)
        } catch (_: Exception) {
        }
    }
}
