package com.c2wake.realme

/**
 * Generated configuration for Realme C2 (RMX1941 / RMX1945 · ColorOS 6 / Android 9).
 * Exported from C2 Wake Studio.
 */
object WakeConfig {
    const val WAKE_KEY = "VOL_UP"           // VOL_UP | VOL_DOWN | EITHER
    const val WAKE_GESTURE = "SINGLE_CLICK"   // SINGLE_CLICK | DOUBLE_CLICK | LONG_PRESS
    const val LOCK_KEY = "VOL_DOWN"           // VOL_UP | VOL_DOWN | EITHER
    const val LOCK_GESTURE = "LONG_PRESS"   // DOUBLE_CLICK | LONG_PRESS | CHORD | DISABLED

    const val DOUBLE_CLICK_WINDOW_MS = 360L
    const val LONG_PRESS_DURATION_MS = 600L

    const val POCKET_PROTECTION = true
    const val MEDIA_SAFEGUARD = true
    const val HAPTIC_FEEDBACK = true
    const val PERSISTENT_NOTIFICATION_LOCK = true
    const val WAKE_ENGINE = "MEDIA_SESSION"     // MEDIA_SESSION | WAKELOCK_ACCESSIBILITY

    const val ACTION_LOCK_SCREEN_NOW = "com.c2wake.realme.ACTION_LOCK_SCREEN_NOW"
}
